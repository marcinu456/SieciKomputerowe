#!/bin/bash
#Marcin Pietrzak
#308025@uwr.edu.pl

echo "#Marcin Pietrzak" > Odp_Marcin_Pietrzak.txt
echo "#308025@uwr.edu.pl" >>Odp_Marcin_Pietrzak.txt

lista_adresow=(156.17.91.0/24 156.17.88.0/24)

for j in "${lista_adresow[@]}" 
do
    my_array=(`nmap -p 80 -v $j | grep -e "port 80/tcp" | awk '{print $NF}'`) # skanowanie portów do tablicy reszta w pętli
    for i in "${my_array[@]}"
    do 
        nazwa=`dig -x $i +short | sed 's/.$//'`
        serwero=`echo -en "GET / HTTP/1.0\n\n\n" | netcat $i 80 | grep Server: | cut -d" " -f2- | sed 's/.$//'` #server
        admino=`dig $nazwa SOA | grep -e "IN\s*SOA\s" | awk '{print($6)}' | sed 's/.$//'`
        if [ -z "$nazwa" ] || [ -z "$serwero" ]  || [ -z "$admino" ] 
        then
            :
        else
            echo "$nazwa;$i;$serwero;$admino" >> Odp_Marcin_Pietrzak.txt
        fi
    done
done